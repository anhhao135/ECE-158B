
Before running the code, use requirements.txt to set up the virtual environment:

pip install -r requirements.txt

Then simply run the main code

python main.py

This will simulate a simple Torrent of 50 peers entering the tracker all at once from the start and attempting to download a file until completion. They will churn upon completion. There will be 3 plots after the simulation is complete to visualize the downloading behaviors.